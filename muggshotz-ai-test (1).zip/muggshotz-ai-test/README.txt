
1. Install Node.js
2. Run npm install
3. Add your API key to .env.local
4. Run npm run dev
