export default function Page() {
  return (
    <main style={{padding:40,fontFamily:'Arial'}}>
      <h1>Muggshotz Caricature Test</h1>
      <p>Project scaffold installed successfully.</p>
      <p>Add your OpenAI API key to .env.local and continue building.</p>
    </main>
  );
}
